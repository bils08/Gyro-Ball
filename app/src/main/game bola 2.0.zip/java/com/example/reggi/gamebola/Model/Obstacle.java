package com.example.reggi.gamebola.Model;

public class Obstacle {
    protected Game game;
    protected int x, y;

    public Obstacle(Game game){
        this.game = game;
    }

    public int getX(){
        return x;
    }

    public int getY(){
        return y;
    }
}
